import sys
from PyQt6.QtWidgets import (QApplication, QListWidget, QListWidgetItem, 
                             QPushButton, QWidget, QHBoxLayout, QLabel)

class ListWithButtonsApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("QListWidget с кнопками")
        self.setGeometry(100, 100, 400, 300)

        # Создаем QListWidget
        self.list_widget = QListWidget(self)
        self.list_widget.setGeometry(10, 10, 380, 280)

        self.add_item_with_button("Элемент 1")
        self.add_item_with_button("Элемент 2")
        self.add_item_with_button("Элемент 3")

    def add_item_with_button(self, text):
        # 1. Создаем QListWidgetItem (это "контейнер" в списке)
        item = QListWidgetItem(self.list_widget)
        button = QPushButton("Нажми меня")
        # 5. Привязываем кастомный виджет к элементу списка
        self.list_widget.setItemWidget(item, button)

    def on_button_clicked(self, item_text):
        print(f"Кнопка в элементе '{item_text}' была нажата!")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = ListWithButtonsApp()
    window.show()
    sys.exit(app.exec())
