import sys
from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtWidgets import (QApplication, QListWidget, QListWidgetItem, 
                             QPushButton, QWidget, QHBoxLayout, QLabel)

from ui import Ui_Form

app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
ui = Ui_Form()
ui.setupUi(Form)

def add_button(ui, text):
    item = QListWidgetItem(ui.menu)
    button = QPushButton(text)
    item.setSizeHint(button.sizeHint())
    ui.menu.setItemWidget(item, button)

add_button(ui, "Игры")
add_button(ui, "Туры")
add_button(ui, "Команды")

print(ui.menu.item)


Form.show()
sys.exit(app.exec())