-- При Insett insert into view_passager values ('0239 669704', 'NINA KOROLEVA new', '{
-- "email": "nkoroleva-081968@postgrespro.ru",
-- "phone": "+70411056715"
-- } ','Comfort')

-- Если мест не хватает, он отменяет операцию (RAISE EXCEPTION)
-- 1.Для Insert в bookings book_ref написать функцию которая генерирует номер брони
--(уникальный набор из 6 символов 16ричной системы счисления)
-- 2. Для Insert в tickets ticket_no написать функцию которая генерирует номер, билета
--(уникальный набор из 13 символов состоящий только из цифр)
-- 3. Для Insert в ticket_flights найти flight_id зная дату и время откуда и куда я лечу (5 баллов)

-- Добавить в триггерную функцию  возможность DELETE, UPDATE (5 баллов) 


create or replace view view_passenger as
select 
    t.passenger_id, 
    t.passenger_name, 
    t.contact_data, 
    tf.fare_conditions,
    f.scheduled_departure, 
    f.departure_airport, 
    f.arrival_airport,
    f.flight_id
from tickets t
	join ticket_flights tf on t.ticket_no = tf.ticket_no
	join flights f on tf.flight_id = f.flight_id;

-- 1. Генерация book_ref (6 символов, 16-ричная система)
create or replace function generate_book_ref() RETURNS text as $$
DECLARE
    new_ref text;
    flag boolean;
BEGIN
    loop
        new_ref := upper(substr(md5(random()::text), 1, 6));
        select exists(
            select 1 
            FROM bookings 
            WHERE book_ref = new_ref
        ) INTO flag;
        if not flag then
            RETURN new_ref;
        end IF;
    end loop;
end;
$$ LANGUAGE plpgsql;


-- 2. Генерация ticket_no (13 цифр)
create or replace function generate_ticket_no() RETURNS text as $$
DECLARE
    new_ticket_no text;
    exists_flag boolean;
BEGIN
    loop
        new_ticket_no := lpad((random() * 9999999999999)::bigint::text, 13, '0');
        select exists(
            select 1 
            FROM tickets 
            WHERE ticket_no = new_ticket_no
        ) INTO exists_flag;
        if not exists_flag then
            RETURN new_ticket_no;
        end IF;
    end LOOP;
end;
$$ LANGUAGE plpgsql;




-- Основная триггерная функция

create or replace function trg_view_passenger_logic()
RETURNS TRIGGER as $$
DECLARE
    v_book_ref text;
    v_ticket_no text;
    v_flight_id int;
    v_seats_left int;
BEGIN
    -- ======================== INSERT ========================
    if (TG_OP = 'INSERT') THEN
        -- 3. Находим flight_id по условиям (откуда, куда, время)
        select flight_id INTO v_flight_id
        from flights
        where departure_airport = new.departure_airport
          AND arrival_airport = new.arrival_airport
          AND scheduled_departure = new.scheduled_departure;

        if v_flight_id IS NULL THEN
            RAISE EXCEPTION 'Рейс не найден на указанное время и/или направление';
        END if;

        -- Проверка свободных мест
        select count(*) INTO v_seats_left
        from seats s
        where s.aircraft_code = (select aircraft_code from flights where flight_id = v_flight_id)
          AND s.fare_conditions = new.fare_conditions
          AND s.seat_no NOT IN (select seat_no from boarding_passes where flight_id = v_flight_id);

        if v_seats_left <= 0 THEN
            RAISE EXCEPTION 'Мест класса % на рейсе % не осталось!', new.fare_conditions, v_flight_id;
        END if;

        -- Генерация
        v_book_ref := generate_book_ref();
        v_ticket_no := generate_ticket_no();

        -- Вставка в таблицы
        INSERT INTO bookings (book_ref, book_date, total_amount)
        VALUES (v_book_ref, now(), 0);

        INSERT INTO tickets (ticket_no, book_ref, passenger_id, passenger_name, contact_data)
        VALUES (v_ticket_no, v_book_ref, new.passenger_id, new.passenger_name, new.contact_data);

        INSERT INTO ticket_flights (ticket_no, flight_id, fare_conditions, amount)
        VALUES (v_ticket_no, v_flight_id, new.fare_conditions, 0);

        RETURN new;

    -- ======================== UPDATE ========================
    ELSIF (TG_OP = 'UPDATE') THEN
        -- Обновляем данные пассажира в основной таблице
        UPDATE tickets SET
            passenger_name = new.passenger_name,
            contact_data = new.contact_data
        where passenger_id = OLD.passenger_id;
        
        -- Если сменился класс обслуживания
        if OLD.fare_conditions <> new.fare_conditions THEN
            UPDATE ticket_flights SET fare_conditions = new.fare_conditions
            where ticket_no = (select ticket_no from tickets where passenger_id = OLD.passenger_id LIMIT 1)
              AND flight_id = OLD.flight_id;
        END if;
        
        RETURN new;

    -- ======================== DELETE ========================
    ELSIF (TG_OP = 'DELETE') THEN
        DELETE from ticket_flights 
        where ticket_no = (select ticket_no from tickets where passenger_id = OLD.passenger_id LIMIT 1);
        
        RETURN OLD;
    END if;
END;
$$ LANGUAGE plpgsql;

-- Регистрация триггера
create TRIGGER trig_view_passenger_manage
INSTEAD OF INSERT or UPDATE or DELETE on view_passenger
FOR EACH ROW EXECUTE function trg_view_passenger_logic();


-- =================== Проверка ===================

select * 
from flights
where flight_id = 1185 and
	status = 'Scheduled';

-- ================ Проверка INSERT ===============
INSERT INTO view_passenger (
    passenger_id, 
    passenger_name, 
    contact_data, 
    fare_conditions, 
    departure_airport, 
    arrival_airport, 
    scheduled_departure
) VALUES (
    '1234 567890', 
    'Иван Иванов', 
    '{"phone": "+79991234567"}', 
    'Economy', 
    'DME', 
    'BTK', 
    '2017-09-10 09:50:00+03'
);

-- Результат таблиц
select * 
from tickets 
where passenger_id = '1234 567890';

select * 
from bookings
where book_ref = (
	select book_ref 
	from tickets 
	where passenger_id = '1234 567890'
);

select *
from view_passenger
where passenger_id = '1234 567890';



-- ============= Проверка UPDATE =============
-- Смена имя и класса
UPDATE view_passenger 
SET passenger_name = 'Иван Пупкин', 
    fare_conditions = 'Business'
where passenger_id = '1234 567890';

-- Результат таблиц
select passenger_name 
from tickets 
where passenger_id = '1234 567890';

select fare_conditions 
from ticket_flights tf 
	join tickets t on tf.ticket_no = t.ticket_no 
where t.passenger_id = '1234 567890';

-- ============= Проверка DELETE =============
DELETE from view_passenger 
where passenger_id = '1234 567890';

-- Результат таблиц
select * 
from ticket_flights tf
	join tickets t on tf.ticket_no = t.ticket_no
where t.passenger_id = '1234 567890';


