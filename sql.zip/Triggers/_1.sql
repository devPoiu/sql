CREATE OR REPLACE FUNCTION trigger_booking_info()
RETURNS TRIGGER AS $$
DECLARE
	total_seats INT;
	booked_seats INT;
	free_seats INT;
	aircraft_code_var varchar;
BEGIN

	RAISE NOTICE 'Триггер сработал! для flight_id: %, ticket_no: %', new.flight_id, new.ticket_no;

	select aircraft_code into aircraft_code_var
	from flights
	where flight_id = new.flight_id;

	RAISE NOTICE 'Код самолёта: %', aircraft_code_var;

	select count(*) into total_seats
	from seats
	where aircraft_code = aircraft_code_var;

	RAISE NOTICE 'Всего мест в самолёте: %', total_seats;

	select count(*) into booked_seats
	from ticket_flights
	where ticket_flights.flight_id = new.flight_id;

	RAISE NOTICE 'Занято мест: %', booked_seats;

	free_seats:= total_seats - booked_seats;

	RAISE NOTICE 'Свободных мест: %', free_seats; 

	IF free_seats <= 0 then
		RAISE NOTICE 'Прерываем insert into в таблицу ticket_flights';
		RAISE EXCEPTION 'Доступных мест нет на рейс %, всего мест %, занято %, доступно %',
			new.flight_id, total_seats, booked_seats, free_seats;
	ELSE
		RAISE NOTICE 'Добавлены данные в таблицу ticket_flights';
	END IF;

	RETURN NEW;
	
END;
$$ LANGUAGE plpgsql;

create or replace trigger trigger_free_seats
before insert on ticket_flights
for each row
execute function trigger_booking_info();

--Триггер срабатывает и выводит ошибку о нехватке свободных мест :)

INSERT INTO ticket_flights (ticket_no, flight_id, fare_conditions, amount)
VALUES ('TEST_FULL0', 11130, 'Economy', 10000);

-- :)))

-- DELETE FROM ticket_flights
-- WHERE 
-- 	ticket_no = 'DEBUG12345' and
-- 	flight_id = 2 and
-- 	fare_conditions = 'Economy' and
-- 	amount = 10000;

--Триггер срабатывает и разрешает вставку данных в таблицу ticket_flights :)
INSERT INTO ticket_flights (ticket_no, flight_id, fare_conditions, amount)
VALUES ('DEBUG12345', 2, 'Economy', 10000); 