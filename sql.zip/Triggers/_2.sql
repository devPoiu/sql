-- Добавим колонку total_revenue в таблицу flights
ALTER TABLE flights 
ADD COLUMN total_revenue NUMERIC(15, 2) DEFAULT 0;


update flights f
set total_revenue = sub.rev
from (
    select flight_id, sum(amount) as rev
    from ticket_flights
    group by flight_id
) sub
where f.flight_id = sub.flight_id;

create or replace function update_flight_revenue()
RETURNS TRIGGER AS $$
begin
    IF (TG_OP = 'INSERT') THEN
        update flights 
        set total_revenue = total_revenue + new.amount
        where flight_id = new.flight_id;
    elseif (TG_OP = 'DELETE') then
        update flights 
        set total_revenue = total_revenue - old.amount
        where flight_id = old.flight_id;
    end if;
    RETURN null;
end;
$$ LANGUAGE plpgsql;


drop trigger if exists trig_update_revenue on ticket_flights;
-- Создание триггера
create trigger trig_update_revenue
after insert or delete on ticket_flights
for EACH row
execute function update_flight_revenue();

-- Проверка результата
select flight_no, departure_airport, arrival_airport, total_revenue
from flights
order by total_revenue desc
limit 5;


-- 1. Подготовка данных для теста
select flight_id, flight_no, total_revenue 
from flights 
where status = 'Scheduled'
limit 1;

select * from ticket_flights
where flight_id = 1185;

-- 2. Проверяем доход в таблице flights
select flight_id, total_revenue 
from flights 
where flight_id = 1185;

-- 3. Добавление билета
insert into ticket_flights (flight_id, ticket_no, fare_conditions, amount)
VALUES (1185, '0005432873504', 'Economy', 5000.00);

-- 4. Снова проверяем доход
select flight_id, total_revenue 
from flights 
where flight_id = 1185;

-- 5. Удаление билета
delete from ticket_flights 
where ticket_no = '0005432873504' AND flight_id = 1185;

