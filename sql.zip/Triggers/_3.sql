-- 3 задание Триггер для логирования изменений статуса рейса

-- создаём таблицу сохранения данных после обновления, логирования статуса рейса
CREATE TABLE flight_logs (
    id SERIAL PRIMARY KEY,
    flight_id INTEGER NOT NULL,
    old_status VARCHAR(20),
    new_status VARCHAR(20),
    change_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- создаём функцию для логирования статуса
create or replace function log_status()
returns trigger as $$
begin
	if old.status != new.status then -- если старый статус не равен новому, то добавляем данные 
		-- в таблицу flight_logs
		insert into flight_logs (flight_id, old_status, new_status) -- добавляем данные в таблицу
		values (
			NEW.flight_id,
            OLD.status,
            NEW.status
		);

		raise notice 'Статус для рейса % обновлён с % на новый %', -- выводим сообщение в консоли
			new.flight_id, old.status, new.status;
	end if;

	return new;
end;
$$ language plpgsql;

-- создаём триггер, работающий после обновления данных в таблицу flights
create or replace trigger trid_on_log_status
after update on flights
for each row
execute function log_status();

-- находим статусы из таблицы flights
SELECT flight_id, flight_no, status 
FROM flights 
WHERE flight_id = 1 -- 2
LIMIT 5;

-- обновляем статус для рейса
UPDATE flights 
SET status = 'Delayed'  
WHERE flight_id = 1; --2 

-- проверка, что статус изменился
select flight_id, flight_no, status as new_status 
from flights 
where flight_id = 1; --2

-- проверяем данные в таблице flight_logs
select * from flight_logs;

-- insert into flights () values ()

