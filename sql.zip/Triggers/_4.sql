-- DROP TRIGGER IF EXISTS trig_not_replay_passenger_on_reise ON tickets;

-- 4 задание Предотвращение повторного бронирования одного и того же пассажира на рейс.

-- 1) создаём триггер на предотвращение повторного бронирования одного и того же пассажира на рейс
create or replace function not_replay_passenger_on_reise()
returns trigger as $$
begin 
    -- Проверяем: есть ли уже у этого пассажира (из таблицы tickets) 
    -- другой билет на этот же рейс (flight_id)
    if exists (
        select 1
        from ticket_flights tf
        join tickets t on tf.ticket_no = t.ticket_no
        where tf.flight_id = new.flight_id
          and t.passenger_id = (select passenger_id from tickets where ticket_no = new.ticket_no)
    ) then 
        raise exception 'Пассажир уже зарегистрирован на рейс %', new.flight_id;
    end if;

    return new;
end;
$$ language plpgsql;


-- 4) создаём триггер, направленный до добавления данных в таблицу 
create or replace trigger trig_not_replay_passenger_on_reise
before insert on ticket_flights
for each row
execute function not_replay_passenger_on_reise();

-- 5) Создаем тестовые данные
INSERT INTO bookings (book_ref, book_date, total_amount) 
VALUES ('TEST1', NOW(), 10000);

-- 6) Первый билет для пассажира
INSERT INTO tickets (ticket_no, book_ref, passenger_id, passenger_name)
VALUES ('TICK1', 'TEST1', '1234 888980', 'Petr Ivanov');

INSERT INTO ticket_flights (ticket_no, flight_id, fare_conditions, amount)
VALUES ('TICK1', 1, 'Economy', 10000);

-- 7) Пытаемся создать второй билет для того же пассажира на тот же рейс
INSERT INTO tickets (ticket_no, book_ref, passenger_id, passenger_name)
VALUES ('TICK1', 'TEST1', '1234 888980', 'Petr Ivanov');

-- -- 8) Эта вставка по идее вызвает ошибку
-- INSERT INTO ticket_flights (ticket_no, flight_id, fare_conditions, amount)
-- VALUES ('TICK1', 1, 'Business', 15000);