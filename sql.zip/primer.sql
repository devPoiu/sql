-- 1. SELECT

SELECT столбец1, столбец2  -- Что выбираем (* для всех столбцов)
FROM имя_таблицы          -- Откуда выбираем
WHERE условие             -- Фильтрация (например, id = 5)
GROUP BY столбец          -- Группировка (для функций типа SUM, AVG)
HAVING условие            -- Фильтрация после группировки
ORDER BY столбец ASC|DESC -- Сортировка (по возрастанию/убыванию)
LIMIT количество;         -- Ограничение числа строк (в некоторых БД TOP или FETCH)


-- Работа с подзапросами

SELECT name FROM users
WHERE id IN (SELECT user_id FROM orders WHERE status = 'delivered');


-- 2. INSERT

INSERT INTO имя_таблицы (столбец1, столбец2, ...)
VALUES (значение1, значение2, ...);
-- Пример вставки нескольких строк сразу:
INSERT INTO users (name, age) 
VALUES ('Ivan', 25), ('Maria', 30);


-- 3. UPDATE

UPDATE имя_таблицы
SET столбец1 = значение1, столбец2 = значение2
WHERE условие; -- ОЧЕНЬ ВАЖНО: без WHERE обновятся ВСЕ строки в таблице!


-- 4. DELETE 

DELETE FROM имя_таблицы
WHERE условие; -- ОЧЕНЬ ВАЖНО: без WHERE удалятся ВСЕ данные из таблицы!


-- 5. CREATE TABLE

CREATE TABLE имя_таблицы (
    id INT PRIMARY KEY,        -- Целое число, первичный ключ
    имя_колонки ТИП_ДАННЫХ,     -- Например, VARCHAR(50) для текста
    создано TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Значение по умолчанию
);

-- 6. ALTER TABLE — Изменение таблицы

ALTER TABLE имя_таблицы ADD имя_колонки ТИП_ДАННЫХ;    -- Добавить
ALTER TABLE имя_таблицы DROP COLUMN имя_колонки;      -- Удалить
ALTER TABLE имя_таблицы MODIFY COLUMN имя_колонки ТИП; -- Изменить тип (в MySQL)


-- 7. Функции

-- 1)
CREATE OR REPLACE FUNCTION имя_функции(параметр1 тип, параметр2 тип)
RETURNS тип_возврата AS $$
BEGIN
    RETURN (SELECT параметр1 + параметр2); -- Пример логики
END;
$$ LANGUAGE plpgsql;

-- 2)
CREATE [OR REPLACE] FUNCTION имя_функции (аргумент1 тип, аргумент2 тип)
RETURNS тип_данных AS $$
DECLARE
    -- Здесь объявляются внутренние переменные
    peremennaya_1 тип; 
BEGIN
    -- Здесь пишется логика (тело функции)
    peremennaya_1 := аргумент1 + аргумент2; -- Оператор присваивания :=
    
    RETURN peremennaya_1; -- Возврат результата
END;
$$ LANGUAGE plpgsql;

-----------------------------------------------------------------
CREATE OR REPLACE FUNCTION get_users_by_city(p_city text)
RETURNS TABLE(user_id int, user_name text) AS $$
BEGIN
    RETURN QUERY 
    SELECT id, name FROM users WHERE city = p_city;
END;
$$ LANGUAGE plpgsql;
-----------------------------------------------------------------
CREATE OR REPLACE FUNCTION is_admin(p_id int)
RETURNS boolean AS $$
BEGIN
    RETURN EXISTS(SELECT 1 FROM admins WHERE id = p_id);
END;
$$ LANGUAGE plpgsql;
-----------------------------------------------------------------


-- 8. Триггеры

-- Шаг 1: Создание триггерной функции
CREATE OR REPLACE FUNCTION log_changes()
RETURNS TRIGGER AS $$
BEGIN
    -- NEW — это строка, которую вставляют/обновляют
    -- OLD — это строка до изменений
    IF (TG_OP = 'UPDATE') THEN
        INSERT INTO audit_log(user_id, changed_at) VALUES (NEW.id, NOW());
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;


-- Шаг 2: Привязка триггера к таблице
CREATE TRIGGER имя_триггера
AFTER UPDATE ON имя_таблицы -- Когда срабатывать (BEFORE/AFTER)
FOR EACH ROW                -- Для каждой строки
EXECUTE FUNCTION log_changes();


-- 9. Представления

CREATE OR REPLACE VIEW view_popular_products AS
SELECT p.name, COUNT(o.id) as sales_count
FROM products p
JOIN orders o ON p.id = o.product_id
GROUP BY p.name
HAVING COUNT(o.id) > 10;
