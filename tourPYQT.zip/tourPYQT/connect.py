import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT


con_tours = {    
        'database': "tours", 
        'user': "postgres", 
        'password': "12345", 
        'host': "localhost",
        'port': "5432"
    }