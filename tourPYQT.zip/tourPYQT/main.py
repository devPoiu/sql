import sys
from ui import Ui_Form
from PyQt6 import QtWidgets
# from tables.games import games
# from tables.teams import teams
from tables.tours import tours



app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
ui = Ui_Form()
ui.setupUi(Form)

ui.menu.currentRowChanged.connect(ui.stackedWidget.setCurrentIndex)

tours(ui)

Form.show()
sys.exit(app.exec())