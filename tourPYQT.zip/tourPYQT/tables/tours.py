import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem
from connect import con_tours

def tours(ui):
    
    ui.okTours.setVisible(False)
    global modelTableTours
    modelTableTours = QStandardItemModel()
    
    def createTable():
        db = psycopg2.connect(**con_tours)
        cursor = db.cursor()
        cursor.execute('''
                    select 
                        id_tour id,
                        number_tour Тур, 
                        data_tour Дата
                    from 
                        tours;''')
        tableTours = cursor.fetchall()  
        db.commit()
        db.close()
        
        header = [f[0] for f in cursor.description] + ['']
        modelTableTours.clear()
        modelTableTours.setHorizontalHeaderLabels(header)
        for tab in tableTours:
            items = []
            for item in tab:
                items.append(QStandardItem(str(item)))
            modelTableTours.appendRow(items)
            
        ui.TVTours.setModel(modelTableTours)
        
        for num, tab in enumerate(tableTours):
            but = QtWidgets.QPushButton('Изменить')
            Tours_id = tab[0]
            but.clicked.connect(lambda checked, n=Tours_id : change_Tours(n))
            index = modelTableTours.index(num, len(header)-1)
            ui.TVTours.setIndexWidget(index, but)
        
    def add_Tours():
        db = psycopg2.connect(**con_tours)
        cursor = db.cursor()
        cursor.execute('''
    INSERT INTO Tours (number_tour, data_tour)
    VALUES (%s, %s);
    ''', (
            ui.numberTour.text(),
            ui.dataTour.text()
        ))
        db.commit()
        db.close()
        createTable()
        
    
    def change_Tours(Tours_id):
        ui.okTours.setVisible(True)
        try:
            ui.okTours.clicked.disconnect()
        except TypeError:
            pass
        ui.okTours.clicked.connect(lambda : update_Tours(Tours_id))
        Tours_id-=1
        ui.numberTour.setText(dataCell_Tours(Tours_id, 1)),
        ui.dataTour.setText(dataCell_Tours(Tours_id, 2))
        
    def update_Tours(row):
        row+=1
        db = psycopg2.connect(**con_tours)
        cursor = db.cursor()
        cursor.execute(f'''select * from tours;''')
        res = cursor.fetchall()
        for ress in res:
            print(ress)
        cursor.execute('''
    UPDATE 
        tours
    SET 
        number_tour = %s, 
        data_tour = %s
    WHERE 
        id_tour = %s
    ''', (
            ui.numberTour.text(),
            ui.dataTour.text(),
            row
        ))
        cursor.execute(f'''select * from tours;''')
        res = cursor.fetchall()
        for ress in res:
            print(ress)
        db.commit()
        db.close()
        ui.numberTour.setText('')
        ui.dataTour.setText('')
        createTable()
        ui.okTours.setVisible(False)
        
    def dataCell_Tours(row, column):
        index = modelTableTours.index(row, column)
        value = modelTableTours.data(index, QtCore.Qt.ItemDataRole.DisplayRole)
        return value
    
    ui.addTours.clicked.connect(add_Tours)
    createTable()