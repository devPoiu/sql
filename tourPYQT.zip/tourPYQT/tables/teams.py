import psycopg2
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem
from connect import con_tours

def teams(ui):
    
    ui.okTeams.setVisible(False)
    global modelTableTeams
    modelTableTeams = QStandardItemModel()
    
    def createTable():
        db = psycopg2.connect(**con_tours)
        cursor = db.cursor()
        cursor.execute('''
            SELECT 
                id_team AS id,
                title_team AS Команда
            FROM 
                teams;
        ''')
        tableTeams = cursor.fetchall()  
        db.commit()
        db.close()
        
        header = [f[0] for f in cursor.description] + ['']
        modelTableTeams.clear()
        modelTableTeams.setHorizontalHeaderLabels(header)
        for tab in tableTeams:
            items = []
            for item in tab:
                items.append(QStandardItem(str(item)))
            modelTableTeams.appendRow(items)
            
        ui.TVTeams.setModel(modelTableTeams)
        
        for num, tab in enumerate(tableTeams):
            but = QtWidgets.QPushButton('Изменить')
            Teams_id = tab[0]
            but.clicked.connect(lambda checked, n=Teams_id : change_Teams(n)) 
            index = modelTableTeams.index(num, len(header)-1)
            ui.TVTeams.setIndexWidget(index, but)
        ui.TVTeams.hideColumn(0)
        
    def add_Teams():
        db = psycopg2.connect(**con_tours)
        cursor = db.cursor()
        cursor.execute('''
            INSERT INTO Teams (title_team)
            VALUES (%s);
        ''', (
            ui.titleTeam.text(),
        ))
        db.commit()
        db.close()
        createTable()
        
    
    def change_Teams(Teams_id_db):
        ui.okTeams.setVisible(True)
        try:
            ui.okTeams.clicked.disconnect()
        except TypeError:
            pass
        ui.okTeams.clicked.connect(lambda : update_Teams(Teams_id_db))
        model_row_index = -1
        for i in range(modelTableTeams.rowCount()):
            index = modelTableTeams.index(i, 0)
            if int(modelTableTeams.data(index)) == Teams_id_db:
                model_row_index = i
                break

        if model_row_index != -1:
            ui.titleTeam.setText(dataCell_Teams(model_row_index, 1))
        
    def update_Teams(Teams_id_to_update):
        db = psycopg2.connect(**con_tours)
        cursor = db.cursor()
        cursor.execute('''
            UPDATE 
                teams
            SET 
                title_team = %s
            WHERE 
                id_team = %s
        ''', (
            ui.titleTeam.text(),
            Teams_id_to_update
        ))
        db.commit()
        db.close()
        ui.titleTeam.setText('')
        createTable()
        ui.okTeams.setVisible(False)
        
    def dataCell_Teams(row, column):
        index = modelTableTeams.index(row, column)
        value = modelTableTeams.data(index, QtCore.Qt.ItemDataRole.DisplayRole)
        return value
    
    ui.addTeams.clicked.connect(add_Teams)
    createTable()
