import psycopg2
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem
from connect import con_tours

current_game_id_to_update = None 

def games(ui):
    
    ui.okGames.setVisible(False)
    global modelTableGames
    modelTableGames = QStandardItemModel()
    
    def createTable():
        db = psycopg2.connect(**con_tours)
        cursor = db.cursor()
        cursor.execute('''
            SELECT 
                g.id_game AS id,
                t.number_tour AS Тур,
                tm1.title_team AS Команда_1,
                tm2.title_team AS Команда_2,
                result_game_1 AS Игра_1,
                result_game_2 AS Игра_2,
                result_game_3 AS Игра_3
            FROM 
                games g
            JOIN 
                tours t ON g.id_tour = t.id_tour
            JOIN 
                teams tm1 ON g.id_team_1 = tm1.id_team
            JOIN 
                teams tm2 ON g.id_team_2 = tm2.id_team
            ORDER BY
                t.number_tour, g.id_game;
        ''')
        tableGames = cursor.fetchall()
        for ress in tableGames:
            print(ress)
        db.commit()
        db.close()
        
        header = [f[0] for f in cursor.description] + ['']
        modelTableGames.clear()
        modelTableGames.setHorizontalHeaderLabels(header)
        for tab in tableGames:
            items = []
            for item in tab:
                items.append(QStandardItem(str(item)))
            modelTableGames.appendRow(items)
            
        ui.TVGames.setModel(modelTableGames)
        
        for num, tab in enumerate(tableGames):
            but = QtWidgets.QPushButton('Изменить')
            Games_id = tab[0]
            but.clicked.connect(lambda checked, n=Games_id : change_Games(n)) 
            index = modelTableGames.index(num, len(header)-1)
            ui.TVGames.setIndexWidget(index, but)

        # ui.TVGames.hideColumn(0)
        
    def add_Games():
        db = psycopg2.connect(**con_tours)
        cursor = db.cursor()
        cursor.execute('''
            INSERT INTO Games (id_tour, id_team_1, id_team_2, result_game_1, result_game_2, result_game_3)
            VALUES (%s, %s, %s, %s, %s, %s);
        ''', (
            ui.idTour.text(),
            ui.idTeam_1.text(),
            ui.idTeam_2.text(),
            ui.game1.text(),
            ui.game2.text(),
            ui.game3.text()
        ))
        db.commit()
        db.close()
        clear_inputs()
        createTable()
        
    def change_Games(Games_id_db):
        global current_game_id_to_update
        current_game_id_to_update = Games_id_db
        ui.okGames.setVisible(True)
        
        db = psycopg2.connect(**con_tours)
        cursor = db.cursor()
        cursor.execute('''
            SELECT 
                id_tour, id_team_1, id_team_2, result_game_1, result_game_2, result_game_3
            FROM 
                games
            WHERE
                id_game = %s;
        ''', (Games_id_db,))
        game_data = cursor.fetchone()
        db.close()

        if game_data:
            ui.idTour.setText(str(game_data[0]))
            ui.idTeam_1.setText(str(game_data[1]))
            ui.idTeam_2.setText(str(game_data[2]))
            ui.game1.setText(str(game_data[3]))
            ui.game2.setText(str(game_data[4]))
            ui.game3.setText(str(game_data[5]))
        try:
            ui.okGames.clicked.disconnect()
        except TypeError:
            pass
        ui.okGames.clicked.connect(update_Games)
        
    def update_Games():
        global current_game_id_to_update

        if current_game_id_to_update is None:
            return

        db = psycopg2.connect(**con_tours)
        cursor = db.cursor()
        cursor.execute('''
            UPDATE 
                games
            SET 
                id_tour = %s, 
                id_team_1 = %s, 
                id_team_2 = %s,
                result_game_1 = %s,
                result_game_2 = %s,
                result_game_3 = %s
            WHERE 
                id_game = %s
        ''', (
            ui.idTour.text(),
            ui.idTeam_1.text(),
            ui.idTeam_2.text(),
            ui.game1.text(),
            ui.game2.text(),
            game(ui.game3.text()),
            current_game_id_to_update
        ))
        db.commit()
        db.close()
        
        clear_inputs()
        createTable()
        ui.okGames.setVisible(False)
        current_game_id_to_update = None
    
    def game(game):
        if game == 'None':
            return None
        else:
            return game
        
    def clear_inputs():
        ui.idTour.setText('')
        ui.idTeam_1.setText('')
        ui.idTeam_2.setText('')
        ui.game1.setText('')
        ui.game2.setText('')
        ui.game3.setText('')
        
    ui.addGames.clicked.connect(add_Games)
    createTable()
