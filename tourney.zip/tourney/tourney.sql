-- drop table games;
-- drop table teams;
-- drop table tours;

create table tours(
	id_tour integer not null primary key,
	number_tour integer not null,
	data_tour date not null
);

create table teams(
	id_team integer not null primary key,
	title_team varchar(50) not null
);

create table games(
	id_game integer not null primary key,
	id_tour integer not null REFERENCES tours(id_tour),
	id_team_1 integer not null references teams(id_team),
	id_team_2 integer not null references teams(id_team),
	result_game_1 integer not null,
	result_game_2 integer not null,
	result_game_3 integer,
	check (id_team_1 <> id_team_2)
);