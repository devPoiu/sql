import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT


# # Установить Рostgresql server
# !sudo apt-get -y -qq update
# !sudo apt-get -y -qq install postgresql
# # запустить сервер под пользоватем postgres
# !sudo service postgresql start
# # Изменить пароль postgres
# !sudo -u postgres psql -U postgres -c "ALTER USER postgres PASSWORD '123456';"

def install():
    con_postgres = {
        'database': "postgres", 
        'user': "postgres", 
        'password': "12345", 
        'host': "localhost",
        'port': "5432"
    }

    con_tours = {    
        'database': "tours", 
        'user': "postgres", 
        'password': "12345", 
        'host': "localhost",
        'port': "5432"
    }


    def select(con, sel, fr):
        conn = psycopg2.connect(**con)
        cursor = conn.cursor()
        cursor.execute(f'''select {sel} from {fr};''')
        res = cursor.fetchall()
        print(cursor.description)
        header = [f[0] for f in cursor.description]
        print(*header)
        conn.close()
        for ress in res:
            print(ress)
        return res

    def queryСommit(con, text):
        conn = psycopg2.connect(**con)
        cursor = conn.cursor()
        cursor.execute(text)
        conn.commit()
        conn.close()
        print(f'gone queryСommit')

    def queryFetch(con, text):
        conn = psycopg2.connect(**con)
        cursor = conn.cursor()
        cursor.execute(text)
        res = cursor.fetchall()
        conn.close()
        return res

    def createDataBase(con, db):
        conn = psycopg2.connect(**con)
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        cursor.execute(f'create database {db};')
        conn.close()
        print(f'createDataBase {db}')

    def deleteDataBase(con, db):
        conn = psycopg2.connect(**con)
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        cursor.execute(f'drop database {db};')
        conn.close()
        print(f'deleteDataBase {db}')

    deleteDataBase(con_postgres, 'tours')
    createDataBase(con_postgres, 'tours')

    queryСommit(con_tours, '''
    create table tours(
        id_tour SERIAL primary key,
        number_tour varchar(15) not null,
        data_tour date not null
    );
    ''')

    queryСommit(con_tours, '''
    create table teams(
        id_team SERIAL primary key,
        title_team varchar(50) not null
    );
    ''')

    queryСommit(con_tours, '''
    create table games(
        id_game SERIAL primary key,
        id_tour integer not null REFERENCES tours(id_tour),
        id_team_1 integer not null references teams(id_team),
        id_team_2 integer not null references teams(id_team),
        result_game_1 integer not null,
        result_game_2 integer not null,
        result_game_3 integer,
        check (id_team_1 <> id_team_2)
    );
    ''')

    queryСommit(con_tours, '''COPY teams FROM 'D:/Ycheb/2course/sql/tourPY/teams.csv' DELIMITER ',' CSV HEADER;''')
    queryСommit(con_tours, '''COPY tours FROM 'D:/Ycheb/2course/sql/tourPY/tours.csv' DELIMITER ',' CSV HEADER;''')
    queryСommit(con_tours, '''COPY games FROM 'D:/Ycheb/2course/sql/tourPY/games.csv' DELIMITER ',' CSV HEADER;''')

    # select(con_tours, '*', 'teams')
    select(con_tours, '*', 'tours')
    # select(con_tours, '*', 'games')
    # select(con_tours, 'number_tour, data_tour, t1.title_team, t2.title_team, result_game_1, result_game_2, result_game_3', 
    #     '''
    #     games g 
    #         join teams t1 on g.id_team_1 = t1.id_team
    #         join teams t2 on g.id_team_2 = t2.id_team
    #         join tours t on g.id_tour = t.id_tour
    #     ''')
    
install()